<?php if (!defined('APPLICATION')) exit(); ?>

<div class="SplashInfo">
   <h1><?php echo T('Maintenance Mode'); ?></h1>
   <p><?php echo T('The site is currently undergoing maintenance.'); ?></p>
</div>
<!-- Domain: <?php echo Gdn::Config('Garden.Domain', ''); ?> -->