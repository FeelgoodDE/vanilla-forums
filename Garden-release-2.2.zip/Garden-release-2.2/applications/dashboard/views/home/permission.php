<?php if (!defined('APPLICATION')) exit(); ?>

<div class="SplashInfo">
   <h1><?php echo T('PermissionErrorTitle', 'Permission Problem'); ?></h1>
   <p><?php echo $this->Data('Message', T('PermissionErrorMessage', "You don't have permission to do that.")); ?></p>
</div>