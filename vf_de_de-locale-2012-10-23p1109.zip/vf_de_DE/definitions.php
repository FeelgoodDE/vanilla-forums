<?php

 $LocaleInfo['vf_de_DE'] = array (
  'Locale' => 'de-DE',
  'Name' => 'German Transifex',
  'Description' => 'German language translations for Vanilla. Help contribute to this translation by going to its translation site <a href="https://www.transifex.com/projects/p/vanilla/language/de_DE/">here</a>.',
  'Version' => '2012.10.23p1109',
  'Author' => 'Vanilla Community',
  'AuthorUrl' => 'https://www.transifex.com/projects/p/vanilla/language/de_DE/',
);
