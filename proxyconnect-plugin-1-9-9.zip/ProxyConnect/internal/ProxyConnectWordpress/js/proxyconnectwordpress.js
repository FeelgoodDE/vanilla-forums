function ProxyConnectWordpress() {

   ProxyConnectWordpress.prototype.Check = function() {
      
   }
   
}

var ProxyConnectWordpress = new ProxyConnectWordpress();