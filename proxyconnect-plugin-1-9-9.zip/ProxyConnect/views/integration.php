<div class="IntegrationManagerConfigure Slice" rel="dashboard/settings/proxyconnect/integration">
   
</div>